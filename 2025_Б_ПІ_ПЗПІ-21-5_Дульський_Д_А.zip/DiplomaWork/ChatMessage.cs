﻿namespace DiplomaWork
{
    public class ChatMessage
    {
        public string Role { get; set; }
        public string Text { get; set; }
    }
}
