﻿using DocumentFormat.OpenXml.Packaging;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using Microsoft.Win32;
using NAudio.Lame;
using NAudio.Utils;
using NAudio.Wave;
using OpenAI;
using OpenAI.Assistants;
using OpenAI.Audio;
using OpenAI.Files;
using OpenAI.VectorStores;
using System.IO;
using System.Printing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
#pragma warning disable OPENAI001
namespace DiplomaWork
{
    public partial class MainWindow : Window
    {
        private OpenAIClient client;
        private OpenAIFileClient fileClient;
        private AssistantClient assistantClient;
        private AudioClient whisperClient;
        private VectorStoreClient vectorStoreClient;

        private WaveInEvent waveIn;
        private MemoryStream memoryStream;
        private WaveFileWriter waveWriter;

        private VectorStore vectorStore;
        private string assistantId;
        private string threadId;

        private bool isRecording = false;
        public ICommand DeleteChatCommand { get; }

        public MainWindow()
        {
            InitializeComponent();
            InitializeAssistant();
        }

        private void InitializeAssistant()
        {
            InputBox.IsEnabled = false;
            SendButton.IsEnabled = false;
            UploadButton.IsEnabled = false;
            RecordButton.IsEnabled = false;
            var apiKey = Environment.GetEnvironmentVariable("OPENAI_API_KEY");
            if (string.IsNullOrWhiteSpace(apiKey))
            {
                MessageBox.Show("API key not found in environment variables.", "Missing API Key", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            whisperClient = new AudioClient("whisper-1", apiKey);
            client = new OpenAIClient(apiKey);
            fileClient = client.GetOpenAIFileClient();
            vectorStoreClient = client.GetVectorStoreClient();
            assistantClient = client.GetAssistantClient();

            ThreadListBox.ItemsSource = ThreadStorage.LoadThreads();
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string text = InputBox.Text;
            InputBox.Text = string.Empty;
            await ProcessInput(text);
        }

        private async Task ProcessInput(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return;

            InputBox.IsEnabled = false;
            SendButton.IsEnabled = false;
            UploadButton.IsEnabled = false;
            RecordButton.IsEnabled = false;
            ThreadListBox.IsEnabled = false;
            NewChat.IsEnabled = false;

            AddChatMessage("User", input);

            var thinkingMessage = new ChatMessage
            {
                Role = "Assistant",
                Text = "[Assistant is thinking...]"
            };
            ChatList.Items.Add(thinkingMessage);
            ChatList.ScrollIntoView(ChatList.Items[ChatList.Items.Count - 1]);

            string prompt = File.Exists(input) ? ReadFileContent(input) : input;

            var msgs = new List<MessageContent> { MessageContent.FromText(prompt) };
            await assistantClient.CreateMessageAsync(threadId, MessageRole.User, msgs);
            var run = await assistantClient.CreateRunAsync(threadId, assistantId);

            while (!run.Value.Status.IsTerminal)
            {
                await Task.Delay(500);
                run = await assistantClient.GetRunAsync(threadId, run.Value.Id);
            }

            await foreach (var message in assistantClient.GetMessagesAsync(threadId))
            {
                if (message.Role == MessageRole.Assistant)
                {
                    foreach (var content in message.Content)
                    {
                        string text = content.Text;
                        if (content.TextAnnotations != null)
                        {
                            foreach (var annotation in content.TextAnnotations)
                            {
                                text = text.Replace(annotation.TextToReplace, "");
                            }
                        }

                        var thinkingMessageToRemove = ChatList.Items.OfType<ChatMessage>()
                            .FirstOrDefault(m => m.Text == "[Assistant is thinking...]");
                        if (thinkingMessageToRemove != null)
                        {
                            ChatList.Items.Remove(thinkingMessageToRemove);
                        }

                        AddChatMessage("Assistant", text);
                    }
                    break;
                }
            }

            InputBox.IsEnabled = true;
            SendButton.IsEnabled = true;
            RecordButton.IsEnabled = true;
            UploadButton.IsEnabled = true;
            ThreadListBox.IsEnabled = true;
            NewChat.IsEnabled = true;
            InputBox.Focus();
        }

        private void AddChatMessage(string role, string text)
        {
            ChatList.Items.Add(new ChatMessage { Role = role, Text = text });
            ChatList.ScrollIntoView(ChatList.Items[ChatList.Items.Count - 1]);
        }

        private string ReadFileContent(string filePath)
        {
            var ext = Path.GetExtension(filePath).ToLower();
            if (ext == ".txt")
            {
                return File.ReadAllText(filePath);
            }
            else if (ext == ".docx" || ext == ".doc")
            {
                using var wordDoc = WordprocessingDocument.Open(filePath, false);
                return wordDoc.MainDocumentPart.Document.Body.InnerText;
            }
            else if (ext == ".pdf")
            {
                using var reader = new PdfReader(filePath);
                using var pdfDoc = new PdfDocument(reader);
                string text = "";
                for (int i = 1; i <= pdfDoc.GetNumberOfPages(); i++)
                {
                    text += PdfTextExtractor.GetTextFromPage(pdfDoc.GetPage(i)) + "\n";
                }
                return text;
            }
            else throw new Exception("Unsupported file type.");
        }

        private void RecordButton_Click(object sender, RoutedEventArgs e)
        {
            if (!isRecording)
            {
                InputBox.IsEnabled = false;
                SendButton.IsEnabled = false;
                UploadButton.IsEnabled = false;
                ThreadListBox.IsEnabled = false;
                NewChat.IsEnabled = false;

                memoryStream = new MemoryStream();
                waveIn = new WaveInEvent { WaveFormat = new WaveFormat(44100, 1) };
                waveWriter = new WaveFileWriter(new IgnoreDisposeStream(memoryStream), waveIn.WaveFormat);

                waveIn.DataAvailable += (s, a) =>
                {
                    waveWriter.Write(a.Buffer, 0, a.BytesRecorded);
                    waveWriter.Flush();
                };

                waveIn.RecordingStopped += (s, a) =>
                {
                    waveWriter.Dispose();
                    waveIn.Dispose();
                    SaveRecordingAsMp3();
                };

                InputBox.Text = String.Empty;
                waveIn.StartRecording();
                isRecording = true;
                RecordButton.Content = "⏹ Stop";
            }
            else
            {
                RecordButton.IsEnabled = false;
                waveIn.StopRecording();
                isRecording = false;
                RecordButton.Content = "🎙️ Record";
            }
        }

        private string GetUniqueRecordingPath()
        {
            string folder = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string baseName = "recorded";
            string extension = ".mp3";
            int index = 1;

            string filePath;
            do
            {
                filePath = Path.Combine(folder, $"{baseName}_{index}{extension}");
                index++;
            }
            while (File.Exists(filePath));

            return filePath;
        }

        private async void SaveRecordingAsMp3()
        {
            memoryStream.Position = 0;
            string outputPath = GetUniqueRecordingPath();

            try
            {
                using (var reader = new WaveFileReader(memoryStream))
                using (var mp3Writer = new LameMP3FileWriter(outputPath, reader.WaveFormat, LAMEPreset.STANDARD))
                {
                    reader.CopyTo(mp3Writer);
                }

                RecordButton.IsEnabled = false;

                AudioTranscriptionOptions options = new()
                {
                    ResponseFormat = AudioTranscriptionFormat.Simple,
                    Language = "uk",
                    Temperature = 0.0f,
                    Prompt = "Не перекладай мову користувача"
                };

                AudioTranscription transcription = await Task.Run(() =>
                {
                    return whisperClient.TranscribeAudio(outputPath, options);
                });

                File.Delete(outputPath);
                InputBox.Text = transcription.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to save MP3 or transcribe:\n{ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                memoryStream.Dispose();

                InputBox.IsEnabled = true;
                RecordButton.IsEnabled = true;
                SendButton.IsEnabled = true;
                ThreadListBox.IsEnabled = true;
                UploadButton.IsEnabled = true;
                NewChat.IsEnabled = true;
                InputBox.Focus();
            }
        }

        private async void UploadButton_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() != true) return;


            var filePath = openFileDialog.FileName;
            OverlayGrid.Visibility = Visibility.Visible;
            MainGrid.IsEnabled = false;
            try
            {
                var uploaded = await fileClient.UploadFileAsync(filePath, FileUploadPurpose.Assistants);
                await vectorStoreClient.AddFileToVectorStoreAsync(assistantClient.GetAssistant(assistantId).Value.ToolResources.FileSearch.VectorStoreIds.FirstOrDefault(), uploaded.Value.Id, true);

                string systemNote = $"[System] Файл \"{Path.GetFileName(filePath)}\" завантажено та додано до векторного сховища.";
                await assistantClient.CreateMessageAsync(threadId, MessageRole.User, [MessageContent.FromText(systemNote)]);
                AddChatMessage("system", systemNote);
            }
            finally
            {
                OverlayGrid.Visibility = Visibility.Collapsed;
                MainGrid.IsEnabled = true;
            }

        }

        private async void NewChatButton_Click(object sender, RoutedEventArgs e)
        {
            OverlayGrid.Visibility = Visibility.Visible;
            MainGrid.IsEnabled = false;

            try
            {
                WelcomePanel.Visibility = Visibility.Collapsed;
                var createOp = vectorStoreClient.CreateVectorStore(true);
                vectorStore = createOp.Value;
                var assistantOptions = new AssistantCreationOptions
                {
                    Name = "Resume Extractor",
                    Instructions = "Ти Асистент, який читає PDF файл та надає відповіді на запитання на мові, з якою користувач робив запит.",
                    Tools = { new FileSearchToolDefinition() },
                    ToolResources = new()
                    {
                        FileSearch = new()
                        {
                            VectorStoreIds = { vectorStore.Id }
                        }
                    }
                };

                var assistant = await assistantClient.CreateAssistantAsync("gpt-4o", assistantOptions);
                assistantId = assistant.Value.Id;

                var thread = await assistantClient.CreateThreadAsync();
                threadId = thread.Value.Id;

                string chatName = "Review_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
                ThreadStorage.SaveThread(assistantId, threadId, chatName);
                ThreadListBox.ItemsSource = ThreadStorage.LoadThreads();
                ThreadListBox.Items.Refresh();
                ThreadListBox.SelectedIndex = ThreadListBox.Items.Count - 1;

                string systemNote = "[System] Assistant and thread initialized.";
                await assistantClient.CreateMessageAsync(threadId, MessageRole.User, [MessageContent.FromText(systemNote)]);
                AddChatMessage("system", systemNote);
            }
            finally
            {
                OverlayGrid.Visibility = Visibility.Collapsed;
                MainGrid.IsEnabled = true;
            }
        }

        private async void ThreadListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (ThreadListBox.SelectedItem is not ThreadInfo selectedThread)
            {
                WelcomePanel.Visibility = Visibility.Visible;
                return;
            }
            WelcomePanel.Visibility = Visibility.Collapsed;
            threadId = selectedThread.ThreadId;
            assistantId = selectedThread.AssistantId;
            ChatList.Items.Clear();
            InputBox.Text = string.Empty;

            List<ChatMessage> allMessages = new List<ChatMessage>();
            OverlayGrid.Visibility = Visibility.Visible;
            MainGrid.IsEnabled = false;
            try
            {
                await foreach (var message in assistantClient.GetMessagesAsync(threadId))
                {
                    if (message.Role == MessageRole.Assistant || message.Role == MessageRole.User)
                    {
                        foreach (var content in message.Content)
                        {
                            string text = content.Text;
                            if (content.TextAnnotations != null)
                            {
                                foreach (var annotation in content.TextAnnotations)
                                    text = text.Replace(annotation.TextToReplace, "");
                            }

                            allMessages.Insert(0, new ChatMessage
                            {
                                Role = text.StartsWith("[System]") ? "system" : message.Role.ToString(),
                                Text = text
                            });
                        }
                    }
                }

                foreach (var chatMessage in allMessages)
                {
                    AddChatMessage(chatMessage.Role, chatMessage.Text);
                }
            }
            finally
            {
                OverlayGrid.Visibility = Visibility.Collapsed;
                MainGrid.IsEnabled = true;
            }


            InputBox.IsEnabled = true;
            SendButton.IsEnabled = true;
            UploadButton.IsEnabled = true;
            RecordButton.IsEnabled = true;
            ThreadListBox.IsEnabled = true;
            NewChat.IsEnabled = true;
        }

        private async void InputBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                e.Handled = true;
                string text = InputBox.Text;
                InputBox.Text = string.Empty;
                if (!string.IsNullOrWhiteSpace(text))
                {
                    await ProcessInput(text);
                }
            }
        }

        private async void DeleteChat_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.Tag is ThreadInfo info)
            {
                var result = MessageBox.Show($"Delete chat \"{info.ChatName}\"?", "Confirm Deletion", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    OverlayGrid.Visibility = Visibility.Visible;
                    MainGrid.IsEnabled = false;

                    try
                    {
                        await assistantClient.DeleteAssistantAsync(info.AssistantId);
                        await assistantClient.DeleteThreadAsync(info.ThreadId);
                    }
                    finally
                    {
                        OverlayGrid.Visibility = Visibility.Collapsed;
                        MainGrid.IsEnabled = true;
                    }
                    ThreadStorage.DeleteThread(info.ThreadId);
                    ThreadListBox.SelectionChanged -= ThreadListBox_SelectionChanged;
                    ThreadListBox.ItemsSource = ThreadStorage.LoadThreads();
                    ThreadListBox.Items.Refresh();
                    ThreadListBox.SelectionChanged += ThreadListBox_SelectionChanged;

                    if (threadId == info.ThreadId)
                    {
                        ChatList.Items.Clear();
                        threadId = null;
                        assistantId = null;
                        WelcomePanel.Visibility = Visibility.Visible;
                        InputBox.IsEnabled = false;
                        SendButton.IsEnabled = false;
                        UploadButton.IsEnabled = false;
                        RecordButton.IsEnabled = false;
                    }
                }
            }
        }

    }
}
#pragma warning restore OPENAI001