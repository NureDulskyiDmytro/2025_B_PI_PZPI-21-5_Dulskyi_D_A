﻿using System;
using System.Collections.Generic;
using System.IO;

namespace DiplomaWork
{
    public class ThreadInfo
    {
        public string AssistantId { get; set; }
        public string ThreadId { get; set; }
        public string ChatName { get; set; }
    }

    public static class ThreadStorage
    {
        private static readonly string storagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "threads.txt");

        public static void SaveThread(string assistantId, string threadId, string chatName)
        {
            string entry = $"{assistantId},{threadId},{chatName}";

            if (!File.Exists(storagePath))
            {
                File.WriteAllText(storagePath, entry + Environment.NewLine);
            }
            else
            {
                var existing = new HashSet<string>(File.ReadAllLines(storagePath));
                if (!existing.Contains(entry))
                    File.AppendAllText(storagePath, entry + Environment.NewLine);
            }
        }

        public static List<ThreadInfo> LoadThreads()
        {
            var result = new List<ThreadInfo>();

            if (!File.Exists(storagePath))
                return result;

            foreach (var line in File.ReadAllLines(storagePath))
            {
                var parts = line.Split(',');

                if (parts.Length >= 3)
                {
                    var chatName = string.Join(",", parts, 2, parts.Length - 2);
                    result.Add(new ThreadInfo
                    {
                        AssistantId = parts[0],
                        ThreadId = parts[1],
                        ChatName = chatName
                    });
                }
            }

            return result;
        }

        public static void DeleteThread(string threadId)
        {
            if (!File.Exists(storagePath))
                return;

            var lines = File.ReadAllLines(storagePath);
            var updatedLines = new List<string>();

            foreach (var line in lines)
            {
                var parts = line.Split(',');
                if (parts.Length >= 2 && parts[1] != threadId)
                {
                    updatedLines.Add(line);
                }
            }

            File.WriteAllLines(storagePath, updatedLines);
        }
    }
}
